import Vue from 'vue'
import Router from 'vue-router'
import Layout1 from '@/components/Layout1'
import Layout2 from '@/components/Layout2'
import Layout3 from '@/components/Layout3'
import Layout4 from '@/components/Layout4'
import Layout5 from '@/components/Layout5'
import Layout6 from '@/components/Layout6'
//import LayoutTest from '@/components/Layout-Test'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      alias: '/layout-1',
      name: 'Layout 1',
      navTitle: {
        min: '1',
        max: 'Layout 1'
      },
      component: Layout1
    },
    {
      path: '/layout-2',
      name: 'Layout 2',
      navTitle: {
        min: '2',
        max: 'Layout 2'
      },
      component: Layout2
    },
    {
      path: '/layout-3',
      name: 'Layout 3',
      navTitle: {
        min: '3',
        max: 'Layout 3'
      },
      component: Layout3
    },
    {
      path: '/layout-4',
      name: 'Layout 4',
      navTitle: {
        min: '4',
        max: 'Layout 4'
      },
      component: Layout4
    },
    {
      path: '/layout-5',
      name: 'Layout 5',
      navTitle: {
        min: '5',
        max: 'Layout 5'
      },
      component: Layout5
    },
    {
      path: '/layout-6',
      name: 'Layout 6',
      navTitle: {
        min: '6',
        max: 'Layout 6'
      },
      component: Layout6
    }
    //{
    // path: '/layout-test',
    //  name: 'Layout Test',
    //  component: LayoutTest
    //}
  ]
})
