<template>
  <div id="controlfrog" :class="this.$themeSettings.selectedTheme">

    <div class="cf-nav cf-nav-state-min">
      <a href="" class="cf-nav-toggle" @click.prevent="navToggle()">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </a>
      
      <ul>
        <template v-for="route in routes">
          <router-link tag="li" class="cf-nav-shortcut" :to="route.path" @click.native="navClass()">
            <a :href="route.path" >
              <span class="cf-nav-min">{{ route.navTitle.min }}</span>
              <span class="cf-nav-max">{{ route.navTitle.max }}</span>
            </a>  
          </router-link>
        </template>
      </ul>
    </div>

    <div class="container-fluid cf-container cf-nav-active">
      <router-view></router-view>
    </div>
  </div>
</template>

<script>
export default {
  name: 'controlfrog',
  computed: {
    routes() {
      const routes = this.$router.options.routes.filter(route => route.hasOwnProperty('navTitle'))
      return routes;
    }
  },
  methods: {
    navToggle() {
      const nav = document.querySelector('.cf-nav');
      nav.classList.toggle('cf-nav-state-min');
      nav.classList.toggle('cf-nav-state-max');
      document.querySelector('.cf-container').classList.toggle('cf-nav-state-max');
    },
    navClass(){
      const nav = document.querySelector('.cf-nav');

      if(nav.classList.value.indexOf('cf-nav-state-max') > -1){
        nav.classList.toggle('cf-nav-state-max'); 
        nav.classList.toggle('cf-nav-state-min'); 
      } 
      
      document.querySelector('.cf-container').classList.remove('cf-nav-state-max');
    }
  }
}
</script>

<style src="./assets/scss/controlfrog.scss" lang="scss"></style>