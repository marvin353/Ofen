export const prettyNumber = {
	methods: {
		prettyNumber(number){
			const prettyNumberSuffixes = ["", "K", "M", "bn", "tr"];
			const addCommas = function (nStr){
				const x = '';
				const rgx = /(\d+)(\d{3})/;
				while (rgx.test(x)) {
					x = x.replace(rgx, '$1' + ',' + '$2');
				}
				return x;
			}
			const prettyNumber_rec = (number, i) => {
				if (i == prettyNumberSuffixes.length) {
					return addCommas(Math.round(number*1000)) + prettyNumberSuffixes[i-1];
				}
				if (number / 1000 >= 1) { // 1000+
					return prettyNumber_rec(number / 1000, ++i);
				}
				else {
					const decimals = number - Math.floor(number);
					if (decimals != 0) {
						if (number >= 10) { // 10 - 100
							number = Math.floor(number) + Math.round(decimals*10) / 10 + '';
							number = number.replace(/(.*\..).*$/, '$1');
						}
						else { // 0 - 10
							number = Math.floor(number) + Math.round(decimals*100) / 100 + '';
							number = number.replace(/(.*\...).*$/, '$1');
						}
						return number + prettyNumberSuffixes[i];
					}
					else {
						return Math.floor(number) + prettyNumberSuffixes[i];
					}
				}
			}
			return prettyNumber_rec(number, 0);
			
		}
	}
}