export const metricChange = {
    computed: {
        change(){
            //Calc percentage increase
            const increase = (this.metricCurrent - this.metricBase) / this.metricBase * 100;
            //Calc percentage decrease
            const decrease = (this.metricBase - this.metricCurrent) / this.metricBase * 100;
            
            return this.percentageCalc == 'increase' ? increase : decrease;
        }
    }
}