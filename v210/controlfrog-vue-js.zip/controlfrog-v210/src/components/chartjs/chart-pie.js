import { Pie, mixins } from 'vue-chartjs';
const { reactiveProp } = mixins;

export default Pie.extend({
  mixins: [reactiveProp],
  props: ['options'],
  mounted () {
    const cfParent = this.$refs.canvas.parentElement.parentElement;
    const canvasWidth = cfParent.clientWidth;
    const canvasHeight = cfParent.clientHeight;

    this.$refs.canvas.height = canvasHeight;
    this.$refs.canvas.width = canvasWidth;
    
    this.renderChart(this.chartData, this.options);
  }
})