<template>
  <div class="cf-item">
    <header>
      <p><span></span>{{title}}</p>
    </header>
    <div class="content">
      <div class="cf-svmc">
        <div class="metric">{{prettyNumber(metricCurrent)}}</div>
        <div class="change metric-small" 
          :class="{ 'm-green': positiveChange, 'm-red': !positiveChange }">
          <div :class="arrowDirection" ></div>
          <div>{{change}}%</div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
/*
  Single Metric and Change widget

  Properties:
  - title="Single Metric &amp; Change"
    Type: String
    Default: 'Single Metric & Change'
    Optional title for widget

  - percentageCalc="increase"
    Type: String
    Default: increase
    Allowed Values: increase, decrease
    Description: Do you want to see the percentage increase or decrease between two numbers?

  - percentageChange
    Type: String
    Default: positive
    Allowed values: positive, negative
    Description: Is the percentage change you calcuate positive or negative? 

    Example usage:
    <cfsinglemetric
      title="A Single Metric"
      :data="singlemetric.data"
      percentageCalc="increase"
      percentageChange="positive">
    </cfsinglemetric>

    TODO: Allow specifying format of number eg Money
    
*/

import { metricChange } from '@/components/mixins/metric-change';
import { prettyNumber } from '@/components/mixins/pretty-numbers';

export default {
  name: 'cf-single-metric',
  mixins: [metricChange, prettyNumber],
  props: {
    title: {
      default: 'Single Metric & Change',
      type: String
    },
    data: {
      Type: Array
    },
    percentageCalc: {
      default: 'increase',
      Type: String
    },
    percentageChange: {
      default: 'positive',
      Type: String
    }
  },
  data () {
    return {
      metrics: this.data,
      metricBase: this.data[0],
      metricCurrent: this.data[this.data.length-1]
    }
  },
  computed: {
    positiveChange(){
      return this.percentageChange == 'positive' ? true : false;
    },
    arrowDirection(){
      return this.percentageCalc == 'increase' ? 'arrow-up' : 'arrow-down';
    }
  }
}
</script>