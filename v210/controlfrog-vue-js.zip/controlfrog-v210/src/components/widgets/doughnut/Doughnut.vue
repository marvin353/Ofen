<template>
  <div class="cf-item">
    <header>
      <p><span></span>{{title}}</p>
    </header>
    <div class="content">
      <div class="cf-pie">
        <doughnut-chart
          :chart-data="chartdata"
          :options="chartoptions">
        </doughnut-chart>
      </div>
    </div>
  </div>
</template>

<script>
/*
  Doughnut Chart widget

  Properties:
  - title="Doughnut Chart"
    Type: String
    Default: 'Doughnut chart'
    Optional title for widget

  - :chartdata="data"
    Type: Object
    Description: Your chart datasets

  - :chartoptions="options"
    Type: Object
    Description: Your chart options

  - Uses vue-chartjs: http://vue-chartjs.org/ 
    Refer to the docs for advanced option config and dataset configuration: http://www.chartjs.org/docs/latest/charts/doughnut.html
  
    Example usage:
    <cf-doughnut
      title="A Doughnut Chart"
      :chartdata="doughnut.data"
      :chartoptions="doughnut.options">
    </cf-doughnut>  
    
*/

import DoughnutChart from '@/components/chartjs/chart-doughnut'

export default {
  name: 'cf-doughnut',
  components: {
    DoughnutChart
  },
  props: {
    title: {
      default: 'Doughnut chart',
      type: String
    },
    chartdata:{
      required: true
    },
    chartoptions:{
      type: Object,
      required: true
    }
  }
}
</script>