<template>
  <div class="cf-item">
    <header>
      <p><span></span>{{title}}</p>
    </header>
    <div class="content cf-gauge">
      <div class="val-current">
        <div class="val-min">
          <div class="metric-small">{{min}}</div>
        </div>
        <div class="metric">{{value}}</div>
        <div class="val-max">
          <div class="metric-small">{{max}}</div>
        </div>
      </div>
      <div class="canvas">
        <canvas ref="canvas"></canvas>
      </div>
    </div>
  </div>
</template>

<script>
/*
  Gauge

  Properties:
  - title="Gauge"
    Type: String
    Default: 'Gauge'
    Optional title for widget

  - :min="gauge.min"
    Type: Number
    Required
    Description: Minmum value for gauge
  
  - :max="gauge.max"
    Type: Number
    Required
    Description: Maximum value for gauge

  - :value="gauge.value"
    Type: Number
    Required
    Description: Current value for gauge  

  - If you like, there are lots of other props you can set and control, read plugin information here: http://bernii.github.io/gauge.js/

    Example usage:
    <cf-gauge
      :min="gauge.min"
      :max="gauge.max"
      :value="gauge.value">
    </cf-gauge>
*/

import { Gauge } from '@/assets/lib/gauge';

export default {
  name: 'cf-gauge',
  data () {
    return {
        theGauge: undefined,
        metricSize: ''
      }
  },
  props: {
    title: {
      default: 'Gauge',
      type: String
    },
    min: {
      type: Number,
      required: true
    },
    max: {
      type: Number,
      required: true
    },
    value: {
      type: Number,
      required: true
    }
  },
  watch: {
    value(val) {
      this.update(val)
    }
  },
  methods: {
    update (val) {
      this.theGauge.set(val)
    },
    generateChart() {
      if(this.theGauge){
        return;
      }

      const parentSizes = [this.$refs.canvas.parentElement.clientWidth, Math.round(this.$refs.canvas.parentElement.clientHeight/2.1)]
      const opts = {
        angle: 0.11,
        lineWidth: 0.30,
        radiusScale: 1,
        pointer: {
          length: 0.5,
          strokeWidth: 0.035,
          color: this.$themeSettings[this.$themeSettings.selectedTheme].gauge.pointer
        },
        limitMax: false,     
        limitMin: false,     
        colorStart: this.$themeSettings[this.$themeSettings.selectedTheme].gauge.bar,   
        strokeColor: this.$themeSettings[this.$themeSettings.selectedTheme].gauge.track,
        generateGradient: true,
        highDpiSupport: true
      };
      this.theGauge = new Gauge(this.$refs.canvas).setOptions(opts);
      this.theGauge.maxValue = this.max;
      this.theGauge.setMinValue(this.min);
      this.theGauge.set(this.value);
    }
  },
  mounted() {
    this.$nextTick(this.generateChart);
  }
}
</script>

