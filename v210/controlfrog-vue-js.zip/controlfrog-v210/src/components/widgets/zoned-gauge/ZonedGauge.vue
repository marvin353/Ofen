<template>
  <div class="cf-item">
    <header>
      <p><span></span>{{title}}</p>
    </header>
    <div class="content cf-gauge">
      <div class="val-current">
        <div class="val-min">
          <div class="metric-small">{{min}}</div>
        </div>
        <div class="metric">{{value}}</div>
        <div class="val-max">
          <div class="metric-small">{{max}}</div>
        </div>
      </div>
      <div class="canvas">
        <canvas ref="canvas"></canvas>
      </div>
    </div>
  </div>
</template>

<script>
/*
  Zoned Gauge

  Show a zoned background on a guage.
  Green, Amber, Red.
  Either as a gradient or as specific zones.

  Properties:
  - title="Zoned Gauge"
    Type: String
    Default: 'Zoned Gauge'
    Optional title for widget

  - :min="gauge.min"
    Type: Number
    Required
    Description: Minmum value for gauge
  
  - :max="gauge.max"
    Type: Number
    Required
    Description: Maximum value for gauge

  - :value="gauge.value"
    Type: Number
    Required
    Description: Current value for gauge  

  - gradientOrZones="zones"
    Type: string
    Values: "gradient" or "zones"
    Default: "zones"
    Description: Specify whether the gauge should have a gradient fill or solid zones

  - gradientZoneDirection="left"
    Type: string
    Values: "left" or "right"
    Default: "left"
    Description: Control color order, Green-Amber-Red == left; Red-Amber-Green == right;

  - zoneValues="zonedGauge.zones"
    Type: Array
    Description: Specify the bounds for zones in the following format:
    [
      {min: 0, max: 333},
      {min: 333, max: 666},
      {min: 666, max: 1000},
    ]  

  - If you like, there are lots of other props you can set and control, read plugin information here: http://bernii.github.io/gauge.js/

    Example usage:
    <cf-zoned-gauge
      :min="zonedGauge.min"
      :max="zonedGauge.max"
      :value="zonedGauge.value"
      gradientOrZones="zones"
      gradientZoneDirection="left"
      :zoneValues="zonedGauge.zoneValues">
    </cf-zoned-gauge>
*/

import { Gauge } from '@/assets/lib/gauge';

export default {
  name: 'cf-zoned-gauge',
  data () {
    return {
        theGauge: undefined,
        metricSize: '',
        zoneColors: [
          "#66ce39", 
          "#e89640",
          "#f23c25"
        ]
      }
  },
  props: {
    title: {
      default: 'Zoned Gauge',
      type: String
    },
    min: {
      type: Number,
      required: true
    },
    max: {
      type: Number,
      required: true
    },
    value: {
      type: Number,
      required: true
    },
    gradientOrZones: {
      type: String,
      Default: "zones"
    },
    gradientZoneDirection: {
      type: String,
      Default: "left"
    },
    zoneValues: {
      Type: Array
    }
  },
  watch: {
    value(val) {
      this.update(val)
    }
  },
  methods: {
    update (val) {
      this.theGauge.set(val)
    },
    generateChart() {
      if(this.theGauge){
        return;
      }

      const parentSizes = [this.$refs.canvas.parentElement.clientWidth, this.$refs.canvas.parentElement.clientHeight]
      const opts = {
        angle: 0.11,
        lineWidth: 0.30,
        radiusScale: 1,
        pointer: {
          length: 0.5,
          strokeWidth: 0.035,
          color: this.$themeSettings[this.$themeSettings.selectedTheme].gauge.pointer
        },
        limitMax: false,     
        limitMin: false,     
        colorStart: this.$themeSettings[this.$themeSettings.selectedTheme].gauge.bar,   
        strokeColor: this.$themeSettings[this.$themeSettings.selectedTheme].gauge.track,
        generateGradient: true,
        highDpiSupport: true
      };

      if(this.gradientOrZones === 'gradient'){
        this.gradientZoneDirection === 'right' ? opts.percentColors = [[0.0, "#f23c25" ], [0.50, "#e89640"], [1.0, "#66ce39"]] : opts.percentColors = [[0.0, "#66ce39" ], [0.50, "#e89640"], [1.0, "#f23c25"]];
      }

      if(this.gradientOrZones === 'zones'){
        let zones = [];
        let colors = this.zoneColors;
        if(this.gradientZoneDirection === 'left'){
          zones = colors.map((color, i) => Object.assign({}, this.zoneValues[i], { strokeStyle: color }))
        }
        if(this.gradientZoneDirection === 'right'){
          colors = colors.reverse();
          zones = colors.map((color, i) => Object.assign({}, this.zoneValues[i], { strokeStyle: color }))
        }
        opts.staticZones = zones;
      }

      this.theGauge = new Gauge(this.$refs.canvas).setOptions(opts);
      this.theGauge.maxValue = this.max;
      this.theGauge.setMinValue(this.min);
      this.theGauge.set(this.value);
    }
  },
  mounted() {
    this.$nextTick(this.generateChart);

    
  },
}
</script>