<template>
  <div class="cf-item">
    <header>
      <p><span></span>{{title}}</p>
    </header>
    <div class="content cf-svmc-chart">
      <div class="cf-svmc-metrics">
        <div class="metric">
            {{prettyNumber(metricCurrent)}}
        </div>
        <div class="change" 
          :class="{ 'm-green': positiveChange, 'm-red': !positiveChange }">
          <div :class="arrowDirection" ></div>
          <div class="metric-small">{{change}}%</div>
        </div>
      </div>
      <div class="cf-svmc-bars">
        <bar-chart
          :chart-data="chartdata"
          :options="chartoptions">
        </bar-chart>
      </div>
    </div>
  </div>
</template>

<script>
/*
  Single Metric and Change with Bars widget

  Properties:
  - title="Metric &amp; Bars"
    Type: String
    Default: 'Metric & Bars'
    Optional title for widget

  - :raw="singleMetricBars.raw"
    Type: Array
    Description: Raw number data in an array  

  - :bars="singleMetricBars.bars"
    Type: Object
    Description: Chart data and options required for bar chart. See Bar.vue for more detailed info.  

  - percentageCalc="increase"
    Type: String
    Default: increase
    Allowed Values: increase, decrease
    Description: Do you want to see the percentage increase or decrease between two numbers?

  - percentageChange
    Type: String
    Default: positive
    Allowed values: positive, negative
    Description: Is the percentage change you calcuate positive or negative? 

    Example usage:
    <cf-single-metric-bars
      title="A Single Metric and bars"
      :raw="singleMetricBars.raw"
      :bars="singleMetricBars.bars"
      percentageCalc="increase"
      percentageChange="positive">
    </cf-single-metric-bars>




    
*/

import { metricChange } from '@/components/mixins/metric-change';
import { prettyNumber } from '@/components/mixins/pretty-numbers';
import BarChart from '@/components/chartjs/chart-bar';

export default {
  name: 'cf-single-metric-bars',
  mixins: [metricChange, prettyNumber],
  components: {
    BarChart
  },
  props: {
    title: {
      default: 'Single Metric & Change & Bars',
      type: String
    },
    raw: {
      Type: Array
    },
    bars: {
      Type: Object
    },
    percentageCalc: {
      default: 'increase',
      Type: String
    },
    percentageChange: {
      default: 'positive',
      Type: String
    }
  },
  data () {
    return {
      metrics: this.raw,
      metricBase: this.raw[0],
      metricCurrent: this.raw[this.raw.length-1],
      chartdata: this.bars.data,
      chartoptions: this.bars.options
    }
  },
  computed: {
    positiveChange(){
      return this.percentageChange == 'positive' ? true : false;
    },
    arrowDirection(){
      return this.percentageCalc == 'increase' ? 'arrow-up' : 'arrow-down';
    },
    trendColor(){
      return this.$themeSettings.selectedTheme === 'black' ? [this.$themeSettings.black.trend.color, this.$themeSettings.black.trend.color] : [this.$themeSettings.white.trend.color, this.$themeSettings.white.trend.color];
    }
  }
}
</script>