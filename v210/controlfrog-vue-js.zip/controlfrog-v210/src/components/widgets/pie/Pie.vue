<template>
  <div class="cf-item">
    <header>
      <p><span></span>{{title}}</p>
    </header>
    <div class="content">
      <div class="cf-pie">
        <pie-chart
          :chart-data="chartdata"
          :options="chartoptions">
        </pie-chart>
      </div>
    </div>
  </div>
</template>

<script>
/*
  Pie Chart widget

  Properties:
  - title="Pie Chart"
    Type: String
    Default: 'Pie chart'
    Optional title for widget

  - :chartdata="data"
    Type: Object
    Description: Your chart datasets

  - :chartoptions="options"
    Type: Object
    Description: Your chart options

  - Uses vue-chartjs: http://vue-chartjs.org/ 
    Refer to the docs for advanced option config and dataset configuration: http://www.chartjs.org/docs/latest/charts/doughnut.html
  
    Example usage:
    <cf-pie
      title="A Pie Chart"
      :chartdata="pieChart.data"
      :chartoptions="pieChart.options">
    </cf-pie>
    
*/

import PieChart from '@/components/chartjs/chart-pie'

export default {
  name: 'cf-pie',
  components: {
    PieChart
  },
  props: {
    title: {
      default: 'Pie chart',
      type: String
    },
    chartdata:{
      required: true
    },
    chartoptions:{
      type: Object,
      required: true
    }
  }
}
</script>