<template>
  <div class="cf-item">
    <header>
      <p><span></span>{{title}}</p>
    </header>
    <div class="content">
      <div class="cf-bar">
        <bar-chart
          :chart-data="chartdata"
          :options="chartoptions">
        </bar-chart>
      </div>
    </div>
  </div>
</template>

<script>
/*
  Bar Chart widget

  Properties:
  - title="Bar Chart"
    Type: String
    Default: 'Bar chart'
    Optional title for widget

  - :chartdata="data"
    Type: Object
    Description: Your chart datasets

  - :chartoptions="options"
    Type: Object
    Description: Your chart options

  - Uses vue-chartjs: http://vue-chartjs.org/ 
    Refer to the docs for advanced option config and dataset configuration: http://www.chartjs.org/docs/latest/charts/bar.html
  
    Example usage:
    <cf-bar
      title="A Bar Chart"
      :chartdata="barChart.data"
      :chartoptions="barChart.options">
    </cf-bar>
    
*/

import BarChart from '@/components/chartjs/chart-bar'

export default {
  name: 'cf-bar',
  components: {
    BarChart
  },
  props: {
    title: {
      default: 'Bar chart',
      type: String
    },
    chartdata:{
      required: true
    },
    chartoptions:{
      type: Object,
      required: true
    }
  }
}
</script>