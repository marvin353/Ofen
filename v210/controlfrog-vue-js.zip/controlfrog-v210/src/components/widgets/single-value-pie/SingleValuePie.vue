<template>
  <div class="cf-item">
    <header>
      <p><span></span>{{title}}</p>
    </header>
    <div class="content cf-svp clearfix">
      <div :class="id" :ref="id"></div>
      <div class="metrics">
        <span class="metric" :style="metricSize">{{percent}}</span><br>
        <span class="metric-small">%</span>
      </div>
    </div>
  </div>
</template>

<script>
/*
  Single Value Pie Chart

  Properties:
  - title="Date &amp; Time"
    Type: String
    Default: 'Date & Time'
    Optional title for widget

  - id="svp"
    Type: String
    Required
    Description: A unuiqe identifier for each single value pie chart

  - :percent="svp.percent"
    Type: Number
    Description: The data percent for the chart

  - It is possible to control other things on the pie see the plugin for info: https://github.com/rendro/easy-pie-chart

    Example usage:
    <cf-single-value-pie
      :percent="svp.percent">
    </cf-single-value-pie>
*/

import EasyPieChart from '@/assets/lib/easy-pie-chart';

export default {
  name: 'cf-single-value-pie',
  data () {
    return {
        pieChart: undefined,
        metricSize: ''
      }
  },
  props: {
    id: {
      Type: String,
      required: true
    },
    title: {
      default: 'Single Value Pie Chart',
      type: String
    },
    barColor: {
      type: String
    },
    trackColor: { 
      type: String 
    },
    scaleColor: { 
      default: false 
    },
    lineWidth: {
      type: Number, 
      default: 25
    },
    percent: {
      type: Number, 
      default: 0
    }
  },
  watch: {
    percent(val) {
      this.update(val)
    }
  },
  methods: {
    update (val) {
      this.pieChart.update(val)
    },
    generateChart() {
      if(this.pieChart){
        // No redraw in plugin, need to destroy and rebuild each time
        while (this.$refs[this.id].hasChildNodes()) {
          this.$refs[this.id].removeChild(this.$refs[this.id].lastChild);
        } 
      }

      const minOfWidthAndHeight = Math.min(this.$refs[this.id].parentElement.clientHeight, this.$refs[this.id].parentElement.clientWidth);
      const calcLineWidth = minOfWidthAndHeight < 200 ? 10 : this.lineWidth;
      this.metricSize = minOfWidthAndHeight < 200 && window.outerWidth < 700 ? 'font-size:4.5em' : '';
      const self = this;

      this.pieChart = new EasyPieChart(this.$refs[this.id], {
        barColor: this.barColor ? this.barColor : this.$themeSettings[this.$themeSettings.selectedTheme].singleValuePie.bar,
        trackColor: this.trackColor ? this.trackColor : this.$themeSettings[this.$themeSettings.selectedTheme].singleValuePie.track,
        scaleColor: this.scaleColor,
        scaleLength: 5,
        lineCap: 'butt',
        lineWidth: calcLineWidth,
        size: Math.min(this.$refs[this.id].parentElement.clientHeight, this.$refs[this.id].parentElement.clientWidth)-30,
        rotate: this.rotate,
        animate: {
          duration: 1000,
          enabled: true
        }
      });
      this.update(this.percent);  
    }
  },
  mounted() {
    this.$nextTick(this.generateChart)
    window.addEventListener('resize', this.generateChart);
  },
  beforeDestroy() {
    window.removeEventListener('resize', this.generateChart);
  }
}
</script>