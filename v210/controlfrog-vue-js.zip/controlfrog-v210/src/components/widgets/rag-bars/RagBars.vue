<template>
  <div class="cf-item">
    <header>
      <p><span></span>{{title}}</p>
    </header>
    <div class="content">
      <div class="cf-rag">
        <div class="cf-bars">
          <ul>
            <li 
              v-for="(bar, index) in bars" 
              :key="index" 
              :style="barStyle(index)">
              <div class="cf-bars-bar m-red mb"
                :class="defaultColorsClass[index]">
              </div>
            </li>
          </ul>
        </div>
        <div class="cf-figs" v-if="showFigs">
          <ul>
            <li 
              v-for="(fig, index) in bars" 
              :key="index">
              <div 
                :class="defaultColorsClass[index]"
                :style="figLabelStyle(index)"
                class="cf-figs-fig">
                <p>{{fig}}{{postfix}}</p>
              </div>
            </li>
          </ul>
        </div>
        <div class="cf-txts" v-if="showLabels">
          <ul>
            <li 
              v-for="(label, index) in labels" 
              :key="index">
              <div 
                :class="defaultColorsClass[index]"
                :style="figLabelStyle(index)"
                class="cf-txts-txt">
                <p>{{label}}</p>
              </div>
            </li>
          </ul>
        </div>
      </div>
    </div>
    </div>
  </div>
</template>

<script>
/*
  RAG Bars widget

  Properties:
  - title="RAG Bars"
    Type: String
    Default: 'RAG Bars'
    Optional title for widget

  - :data
    Type: Array
    Description: An array of values in order R A G
  
  - :labels
    Type: Array
    Description: An ordered array of label strings

  - :showLabels
    Type: boolean
    Default: True
    Description: Hide or show the labels
    
  - :showFigs
    Type: boolean
    Default: True
    Description: Hide or show the figures
     
  - :postfix
    Type: String
    Description: A string to append after the figure, like %

  - :customColors
    Type: Array
    Description: An array of hex values to be used instead of default colours, applies to bar background color as well as figure and label text color
    Example: ['#1ccc22','#f13d19','#f25e02'] 

    Example usage:
    <cfragbars
      title="A Rag Bar Chart"
      :data="rag.data"
      :labels="rag.labels"
      postfix="%"
      :showLabels="true"
      :showFigs="true"
      :customColors="['#1ccc22','#f13d19','#a77b60']">
    </cfragbars>


    TODO redo style to get rid of the need for mb-missing.
*/

export default {
  name: 'cf-ragbars',
  props: {
    title: {
      default: 'RAG Bars',
      type: String
    },
    data: {
      type: Array,
      required: true
    },
    labels: {
      type: Array
    },
    showLabels: {
      default: true,
      type: Boolean
    },
    showFigs: {
      default: true,
      type: Boolean
    },
    postfix: {
      type: String
    },
    customColors: {
      default: () => [],
      type: Array
    }
  },
  data () {
    return {
      bars: this.data,
      defaultColorsClass: [
        'm-red',
        'm-amber',
        'm-green'
      ],
    }
  },
  computed: {
    barHeights(){
      const ragTotal = this.bars.reduce((total, amount) => total + amount);
      return this.bars.map(bar => bar/ragTotal * 100);
    }
    
  },
  created() {
    
  },
  methods: {
    barStyle(index) {
      return this.customColors[index] ? "background-color: "+this.customColors[index]+"; height:"+ this.barHeights[index]+"%" : "height:"+ this.barHeights[index]+"%";
    },
    figLabelStyle(index) {
      return this.customColors[index] ? "color: "+this.customColors[index]+";" : "";
    }
  }
}
</script>