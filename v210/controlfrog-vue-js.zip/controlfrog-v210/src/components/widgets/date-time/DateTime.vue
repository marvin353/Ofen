<template>
  <div class="cf-item">
    <header>
      <p><span></span>{{title}}</p>
    </header>
    <div class="content">
      <div class="cf-td">
        <div class="cf-td-time metric">{{time}}</div>
        <div class="cf-td-dd">
          <p class="cf-td-day metric-small">{{day}}</p>
          <p class="cf-td-date metric-small">{{todayDate}}</p>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
/*
  Date & Time widget

  Properties:
  - title="Date &amp; Time"
    Type: String
    Default: 'Date & Time'
    Optional title for widget

  - timezone="Europe/Helsinki"
    Type: String
    Default: Local timezone
    Description: Optional timezone setting 
  
  - :format24hr="false"
    Type: Boolean
    Default: true
    Description: By default times are shown in 24hr format, for 12hr format specify this property as false

    Example usage:
    <cfdatetime
      title="Date &amp; Time"
      timezone="Europe/Helsinki"
      :format24hr="false">
    </cfdatetime>
*/


import moment from 'moment-timezone';
export default {
  name: 'cf-datetime',
  props: {
    title: {
      default: 'Date & Time',
      type: String
    },
    timezone: {
      default: moment.tz.guess()
    },
    format24hr: {
      default: true,
      type: Boolean
    }
  },
  data () {
    return {
      now: new Date()
    }
  },
  computed: {
    time() {
      return moment.tz(this.now, this.timezone).format(this.timeFormat);
    },
    day() {
      return moment.tz(this.now, this.timezone).format('dddd');
    },
    todayDate() {
      return moment.tz(this.now, this.timezone).format('MMMM Do, YYYY');
    },
    timeFormat() {
      return this.format24hr ? 'HH:mm' : 'h:mma';
    }
  },
  created() {
    moment.tz.setDefault()
    setInterval(this.updateTime, 1000)
  },
  methods: {
    updateTime(){
      this.now = new Date();
    }
  }
}
</script>