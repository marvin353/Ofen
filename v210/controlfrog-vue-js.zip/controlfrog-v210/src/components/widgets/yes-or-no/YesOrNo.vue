<template>
  <div class="cf-item">
    <header>
      <p><span></span>{{title}}</p>
    </header>
    <div class="content">
      <div class="cf-yn yn-y">
        <div class="metric"
          :class="colorClass">
          {{label}}
        </div>
      </div>
    </div>
  </div>
</template>

<script>
/*
  Yes or No widget

  Properties:
  - title="Yes or No"
    Type: String
    Default: 'Yes or No'
    Optional title for widget

  - :yes="true"
    Type: Boolean
    Default: true
    Description: By default widget displays "Yes", pass false to display "No"

  - :labelColor="true"
    Type: Boolean
    Default: true
    Description: By default widget displays value in green, pass false to display in red
  
    Example usage:
    <cfyesorno
      title="A Yes or No"
      :yes="true"
      :labelColor="true">
    </cfyesorno>
*/

export default {
  name: 'cf-yes-or-no',
  props: {
    title: {
      default: 'Yes or No',
      type: String
    },
    yes: {
      default: true,
      type: Boolean
    },
    labelColor: {
      default: true,
      type: Boolean
    }
  },
  data () {
    return {
      now: new Date()
    }
  },
  computed: {
    label(){
      return this.yes ? 'YES' : 'NO';
    },
    colorClass(){
      return this.labelColor ? 'm-green' : 'm-red';
    }
  }
}
</script>