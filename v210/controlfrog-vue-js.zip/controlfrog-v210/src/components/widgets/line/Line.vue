<template>
  <div class="cf-item">
    <header>
      <p><span></span>{{title}}</p>
    </header>
    <div class="content">
      <div class="cf-line">
        <line-chart
          :chart-data="chartdata"
          :options="chartoptions">
        </line-chart>
      </div>
    </div>
  </div>
</template>

<script>
/*
  Line Chart widget

  Properties:
  - title="Line Chart"
    Type: String
    Default: 'Line chart'
    Optional title for widget

  - :chartdata="data"
    Type: Object
    Description: Your chart datasets

  - :chartoptions="options"
    Type: Object
    Description: Your chart options

  - Uses vue-chartjs: http://vue-chartjs.org/ 
    Refer to the docs for advanced option config and dataset configuration
  

    Example usage:
    <cf-line
      title="My Line Chart"
      :chartdata="lineChart.data"
      :chartoptions="lineChart.options">
    </cf-line>
    
*/

import LineChart from '@/components/chartjs/chart-line'

export default {
  name: 'cf-line',
  components: {
    LineChart
  },
  props: {
    title: {
      default: 'Line chart',
      type: String
    },
    chartdata:{
      required: true
    },
    chartoptions:{
      type: Object,
      required: true
    }
  }
}
</script>