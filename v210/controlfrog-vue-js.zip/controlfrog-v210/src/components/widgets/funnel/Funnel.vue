<template>
  <div class="cf-item">
    <header>
      <p><span></span>{{title}}</p>
    </header>
    <div class="content">
      <div class="cf-funnel">
        <div class="cf-funnels cf-funnels-left">
          <ul>
            <li 
              v-for="(funnel, index) in funnels" 
              :key="index" 
              :style="funnelStyle(index)"
              class="m-green mb">
            </li>
          </ul>
        </div>
        <div class="cf-figstxts">
          <ul>
            <li 
              v-for="(figlab, index) in figsLabels" 
              :key="index">
              <div>
                <p class="metric m-green mc" 
                  :style="figLabelStyle(index)">
                  {{figlab.value}}</p>
                <p>{{figlab.label}}</p>
              </div>
            </li>
          </ul>
        </div>
      </div>
    </div>
    </div>
  </div>
</template>

<script>
/*
  Funnel Chart Widget

  Properties:
  - title="Funnel Chart"
    Type: String
    Default: 'Funnel Chart'
    Optional title for widget

  - :data
    Type: Array
    Description: An array of values in order
  
  - :labels
    Type: Array
    Description: An ordered array of label strings

  - :barOpacity
    Type: Boolean
    Default: false
    Description: Pass the option as true if you want the bar background color to decrease in opacity from step 1.

  - :customColors
    Type: Array
    Description: An array of hex values to be used instead of default colours, applies to bar background color as well as figure color
    Example: ['#1ccc22','#f13d19','#f25e02','#1182f0']

    Example usage:
     <cffunnelchart
      title="A Funnel Chart"
      :data="funnel.data"
      :labels="funnel.labels"
      :barOpacity="true"
      :customColors="['#1ccc22','#f13d19','#f25e02','#1182f0']">
    </cffunnelchart>

    TODO redo style to get rid of the need for mb-missing.
    TODO left/right align  
*/

export default {
  name: 'cf-funnel-chart',
  props: {
    title: {
      default: 'Funnel Chart',
      type: String
    },
    data: {
      type: Array,
      required: true
    },
    labels: {
      type: Array
    },
    barOpacity: {
      default: false,
      type: Boolean
    },
    customColors: {
      default: () => [],
      type: Array
    }
  },
  data () {
    return {
      funnels: this.data,
    }
  },
  computed: {
    figsLabels(){
      return this.funnels.map((x, i) => ({"value": x, "label": this.labels[i]}))
    },
    barHeight(){
      return 100/this.funnels.length;
    }
  },
  created() {
    
  },
  methods: {
    funnelStyle(index) {
      return [this.funnelBackground(index), this.funnelOpacity(index), this.funnelWidth(index)].join(';');
    },
    funnelOpacity(index){
      return this.barOpacity ? "opacity: "+ (1-(index*(0.5/this.funnels.length))) +""  : "opacity: 1";
    },
    funnelBackground(index){
      return this.customColors[index] ? "background-color: "+this.customColors[index]+"; height:"+ this.barHeight+"%" : "height:"+ this.barHeight+"%";
    },
    funnelWidth(index){
      if(index==0){
        return "width: 100%";
      }
      return "width: "+Math.ceil(this.funnels[index]/this.funnels[0]*100)+"%";
    },
    figLabelStyle(index) {
      return this.customColors[index] ? "color: "+this.customColors[index]+";" : "";
    }
  }
}
</script>