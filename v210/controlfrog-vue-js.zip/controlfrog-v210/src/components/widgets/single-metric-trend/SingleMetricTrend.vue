<template>
  <div class="cf-item">
    <header>
      <p><span></span>{{title}}</p>
    </header>
    <div class="content cf-svmc-chart">
      <div class="cf-svmc-metrics">
        <div class="metric">{{prettyNumber(metricCurrent)}}</div>
        <div class="change" 
          :class="{ 'm-green': positiveChange, 'm-red': !positiveChange }">
          <div :class="arrowDirection" ></div>
          <div class="metric-small">{{change}}%</div>
        </div>
      </div>
      <div class="cf-svmc-trend">
        <line-chart
          :chart-data="chartdata"
          :options="chartoptions">
        </line-chart>
      </div>
    </div>
  </div>
</template>

<script>
/*
  Single Metric and Change with Trend Line widget

  Properties:
  - title="Metric &amp; Trend Line"
    Type: String
    Default: 'Metric & Trend Line'
    Optional title for widget

  - :raw="singleMetricTrend.raw"
    Type: Array
    Description: Raw number data in an array  

  - :trend="singleMetricTrend.trend"
    Type: Object
    Description: Chart data and options required for line chart. See Line.vue for more detailed info.    

  - percentageCalc="increase"
    Type: String
    Default: increase
    Allowed Values: increase, decrease
    Description: Do you want to see the percentage increase or decrease between two numbers?

  - percentageChange
    Type: String
    Default: positive
    Allowed values: positive, negative
    Description: Is the percentage change you calcuate positive or negative? 

    Example usage:
    <cf-single-metric-trend
      title="A Single Metric"
      :raw="singleMetricTrend.data"
      :trend="singleMetricTrend.trend"
      percentageCalc="increase"
      percentageChange="positive">
    </cf-single-metric-trend>
    
*/

import { metricChange } from '@/components/mixins/metric-change';
import { prettyNumber } from '@/components/mixins/pretty-numbers';
import LineChart from '@/components/chartjs/chart-line';

export default {
  name: 'cf-single-metric-trend',
  mixins: [metricChange, prettyNumber],
  components: {
    LineChart
  },
  props: {
    title: {
      default: 'Single Metric & Change & Trend',
      type: String
    },
    raw: {
      Type: Array
    },
    trend: {
      Type: Object
    },
    percentageCalc: {
      default: 'increase',
      Type: String
    },
    percentageChange: {
      default: 'positive',
      Type: String
    }
  },
  data () {
    return {
      metrics: this.raw,
      metricBase: this.raw[0],
      metricCurrent: this.raw[this.raw.length-1],
      chartdata: this.trend.data,
      chartoptions: this.trend.options
    }
  },
  computed: {
    positiveChange(){
      return this.percentageChange == 'positive' ? true : false;
    },
    arrowDirection(){
      return this.percentageCalc == 'increase' ? 'arrow-up' : 'arrow-down';
    },
    trendColor(){
      return this.$themeSettings.selectedTheme === 'black' ? [this.$themeSettings.black.trend.color, this.$themeSettings.black.trend.color] : [this.$themeSettings.white.trend.color, this.$themeSettings.white.trend.color];
    }
  }
}
</script>