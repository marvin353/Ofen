<template>
  <div class="row">
    <div class="col-md-6">
      <div class="row vh-2-3rds">
        <div class="col-md-12">
          <cf-single-metric-area
            :raw="singleMetricArea.raw"
            :trend="singleMetricArea.area"
            percentageCalc="increase"
            percentageChange="positive">
          </cf-single-metric-area>          
        </div>
      </div>
      <div class="row vh-1-3rd">
        <div class="col-sm-6">
          <cf-zoned-gauge
            :min="zonedGauge.min"
            :max="zonedGauge.max"
            :value="zonedGauge.value"
            gradientOrZones="zones"
            gradientZoneDirection="left"
            :zoneValues="zonedGauge.zoneValues">
          </cf-zoned-gauge>
        </div>
        <div class="col-sm-6">
          <cf-date-time
            timezone="Europe/Helsinki">
          </cf-date-time> 
        </div>
      </div>
    </div>

    <div class="col-md-6">
      <div class="row vh-1-3rd">
        <div class="col-sm-6">
          <cf-single-metric-bars
            :raw="singleMetricBars.raw"
            :bars="singleMetricBars.bars"
            percentageCalc="increase"
            percentageChange="positive">
          </cf-single-metric-bars>
        </div>
        <div class="col-sm-6">
          <cf-funnel-chart
            :data="funnel.data"
            :labels="funnel.labels"
            :barOpacity="true">
          </cf-funnel-chart>
        </div>
      </div>
      <div class="row vh-1-3rd">
        <div class="col-sm-6">
          <cf-single-metric
            :data="singleMetric.data"
            percentageCalc="increase"
            percentageChange="positive">
          </cf-single-metric>
        </div>
        <div class="col-sm-6">
          <cf-rag-bars
            :data="rag.data"
            :labels="rag.labels"
            postfix="%">
          </cf-rag-bars>
        </div>
      </div>
      <div class="row vh-1-3rd">
        <div class="col-md-4">
          <cf-single-value-pie
            id="svp1"
            :percent="svp1.percent">
          </cf-single-value-pie>
        </div>
        <div class="col-md-4">
          <cf-single-value-pie
            id="svp"
            :percent="svp.percent">
          </cf-single-value-pie>
        </div>
        <div class="col-md-4">
          <cf-yes-or-no
            :yes="false"
            :labelColor="true">
          </cf-yes-or-no>
        </div>
      </div>

    </div>
  </div>
</template>

<script>
import CfDateTime from '@/components/widgets/date-time/DateTime.vue';
import CfRagBars from '@/components/widgets/rag-bars/RagBars.vue';
import CfFunnelChart from '@/components/widgets/funnel/Funnel.vue';
import CfSingleMetric from '@/components/widgets/single-metric/SingleMetric.vue';
import CfSingleMetricTrend from '@/components/widgets/single-metric-trend/SingleMetricTrend.vue';
import CfSingleMetricArea from '@/components/widgets/single-metric-area/SingleMetricArea.vue';
import CfSingleMetricBars from '@/components/widgets/single-metric-bars/SingleMetricBars.vue';
import CfYesOrNo from '@/components/widgets/yes-or-no/YesOrNo.vue';
import CfSingleValuePie from '@/components/widgets/single-value-pie/SingleValuePie.vue';
import CfGauge from '@/components/widgets/gauge/Gauge';
import CfZonedGauge from '@/components/widgets/zoned-gauge/ZonedGauge';
import CfLine from '@/components/widgets/line/Line';
import CfPie from '@/components/widgets/pie/Pie'
import CfDoughnut from '@/components/widgets/doughnut/Doughnut';
import CfBar from '@/components/widgets/bar/Bar';

export default {
  name: 'layout-1',
  components: {
    CfDateTime,
    CfRagBars,
    CfFunnelChart,
    CfSingleMetric,
    CfSingleMetricTrend,
    CfSingleMetricArea,
    CfSingleMetricBars,
    CfYesOrNo,
    CfSingleValuePie,
    CfGauge,
    CfZonedGauge,
    CfLine,
    CfPie,
    CfDoughnut,
    CfBar
  },
  data () {
    return {
      rag: {
        data: [40,60,20],
        labels: ['Red', 'Amber', 'Green'],
      },
      funnel: {
        data: [3000,1500,500,250,10],
        labels: ['Visits','Cart','Checkout','Purchase','Refund'],
      },
      singleMetric: {
        data: [10000, 200000]
      },
      singleMetricArea: {
        raw: [100, 200, 500, 900, 500, 100, 300, 500, 0, 0, 100, 80, 200, 900, 450],
        area: {
          data: {
            labels: ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O'],
            datasets: [
              {
                backgroundColor: this.$themeSettings[this.$themeSettings.selectedTheme].area.background,
                borderColor: this.$themeSettings[this.$themeSettings.selectedTheme].area.line,
                pointBackgroundColor: this.$themeSettings[this.$themeSettings.selectedTheme].area.pointBackgroundColor,
                pointBorderColor: this.$themeSettings[this.$themeSettings.selectedTheme].area.pointBorderColor,
                
                pointRadius: 1,
                data: [100, 200, 500, 900, 500, 100, 300, 500, 50, 150, 100, 80, 200, 900, 450]
              }
            ]
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            legend: {
              display: false
            },
            scales:{
              xAxes: [{
                  display: false
              }],
              yAxes: [{
                  display: false
              }]
            }
          }
        }
      },
      singleMetricTrend: {
        raw: [100, 200, 500, 900, 500, 100, 300, 500, 0, 0, 100, 80, 200, 900, 450],
        trend: {
          data: {
            labels: ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O'],
            datasets: [
              {
                backgroundColor: this.$themeSettings[this.$themeSettings.selectedTheme].background,
                borderColor: this.$themeSettings[this.$themeSettings.selectedTheme].line.line,
                pointBackgroundColor: this.$themeSettings[this.$themeSettings.selectedTheme].line.pointBackgroundColor,
                pointBorderColor: this.$themeSettings[this.$themeSettings.selectedTheme].line.pointBorderColor,
                lineTension: 0,
                pointRadius: 1,
                data: [100, 200, 500, 900, 500, 100, 300, 500, 50, 150, 100, 80, 200, 900, 450]
              }
            ]
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            legend: {
              display: false
            },
            scales:{
              xAxes: [{
                  display: false
              }],
              yAxes: [{
                  display: false
              }]
            }
          }
        }
      },
      singleMetricBars: {
        raw: [100, 200, 500, 900, 500, 100, 300, 500, 200, 100, 100, 80, 200, 900, 450, 300],
        bars: {
          data: {
            labels: ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p'],
            datasets: [
              {
                backgroundColor: this.$themeSettings[this.$themeSettings.selectedTheme].bar.background,
                data: [100, 200, 500, 900, 500, 100, 300, 500, 200, 100, 100, 80, 200, 900, 450, 300]
              }
            ]
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            legend: {
              display: false
            },
            scales:{
              xAxes: [{
                  display: false,
                  barPercentage: 0.7,
                  categoryPercentage: 1
              }],
              yAxes: [{
                  display: false,
              }]
            },
            barPercentage: 1,
            categoryPercentage: 1
          }
        }
      },
      svp: {
        percent: 72
      },
      svp1: {
        percent: 39
      },
      gauge: {
        min: 0,
        max: 1000,
        value: 500
      },
      zonedGauge: {
        min: 0,
        max: 1000,
        value: 422,
        zoneValues: [
          {min: 0, max: 333},
          {min: 333, max: 666},
          {min: 666, max: 1000},
        ]  
      },
      lineChart: {
        data: {
          labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
          datasets: [
            {
              backgroundColor: this.$themeSettings[this.$themeSettings.selectedTheme].line.background,
              borderColor: this.$themeSettings[this.$themeSettings.selectedTheme].line.line,
              pointBackgroundColor: this.$themeSettings[this.$themeSettings.selectedTheme].line.pointBackgroundColor,
              pointBorderColor: this.$themeSettings[this.$themeSettings.selectedTheme].line.pointBorderColor,
              data: [40, 20, 12, 39, 10, 40, 39, 80, 40, 20, 12, 11]
            }
          ]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          legend: {
            display: false
          },
          scales:{
            xAxes: [{
                display: false
            }]
          },
          layout: {
            padding: {
              right: 4
            }
          }
        }
      },
      barChart: {
        data: {
          labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
          datasets: [
            {
              backgroundColor: this.$themeSettings[this.$themeSettings.selectedTheme].bar.background,
              data: [40, 20, 12, 39, 10, 40, 39, 80, 40, 20, 12, 11]
            }
          ]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          legend: {
            display: false
          },
          scales:{
            xAxes: [{
                display: false,
                barPercentage: 0.7,
                categoryPercentage: 1
            }]
          },
          barPercentage: 1,
          categoryPercentage: 1
        }
      },
      pieChart: {
        data: {
          datasets: [{
              data: [10, 20, 30],
              backgroundColor: [
                this.$themeSettings[this.$themeSettings.selectedTheme].pie.pieSegColors[0],
                this.$themeSettings[this.$themeSettings.selectedTheme].pie.pieSegColors[1],
                this.$themeSettings[this.$themeSettings.selectedTheme].pie.pieSegColors[2],
              ],
              borderColor: this.$themeSettings[this.$themeSettings.selectedTheme].pie.border,
          }],
          labels: [
              'Good',
              'Bad',
              'Ugly'
          ]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          legend: {
            display: true,
            position: 'right'
          }
        }
      },
      doughnut: {
        data: {
          datasets: [{
              data: [10, 20, 30],
              backgroundColor: [
                this.$themeSettings[this.$themeSettings.selectedTheme].pie.pieSegColors[0],
                this.$themeSettings[this.$themeSettings.selectedTheme].pie.pieSegColors[1],
                this.$themeSettings[this.$themeSettings.selectedTheme].pie.pieSegColors[2],
              ],
              borderColor: this.$themeSettings[this.$themeSettings.selectedTheme].pie.border,
          }],
          labels: [
              'Good',
              'Bad',
              'Ugly'
          ]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          legend: {
            display: true,
            position: 'right'
          }
        }
      }
    }
  }
}
</script>