// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import router from './router'

Vue.config.productionTip = false;

Vue.prototype.$themeSettings = {
  selectedTheme: 'black',
  black: {
    metric: '#f2f2f2',
    background: '#2b2b2b',
    trend: {
      color: '#ffffff'
    },
    singleValuePie: {
      track: '#7d7d7d',
      bar: '#f2f2f2'
    },
    gauge: {
      track: '#4f4f4f',
      bar: '#898989',
      pointer: '#f2f2f2'
    },
    line: {
      line: '#ffffff',
      background: '#363636',
      pointBackgroundColor: '#ffffff',
      pointBorderColor: '#ffffff',
    },
    area: {
      line: '#363636',
      background: '#232323',
      pointBackgroundColor: '#363636',
      pointBorderColor: '#363636',
    },
    pie: {
      pieSegColors: ['#f2f2f2','#c0c0c0','#8e8e8e','#5b5b5b','#292929'],
      border: '#2b2b2b'
    },
    bar: {
      background: '#f2f2f2'
    }
  },
  white: {
    metric: '#7d7d7d',
    background: '#fff',
    trend: {
      color: '#7d7d7d'
    },
    singleValuePie: {
      track: '#a9a9a9',
      bar: '#7d7d7d'
    },
    gauge: {
      track: '#a9a9a9',
      bar: '#7d7d7d',
      pointer: '#ccc'
    },
    line: {
      line: '#7d7d7d',
      background: '#EFEFEF',
      pointBackgroundColor: '#7d7d7d',
      pointBorderColor: '#7d7d7d',
    },
    area: {
      line: '#363636',
      background: '#7d7d7d',
      pointBackgroundColor: '#363636',
      pointBorderColor: '#363636',
    },
    pie: {
      pieSegColors: ['#7d7d7d','#868686','#636363','#404040','#1d1d1d'],
      border: '#fff'
    },
    bar: {
      background: '#7d7d7d'
    }
  }
}

/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  template: '<App/>',
  components: { App }
})